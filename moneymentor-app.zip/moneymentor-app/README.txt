MoneyMentor - three separate pages
  index.html    = Login page (Gmail / Phone code)
  app.html      = Tracker page (after login)
  enquiry.html  = Enquiry / contact page
Upload ALL files and the icons folder together (GitHub Pages or Netlify Drop).
